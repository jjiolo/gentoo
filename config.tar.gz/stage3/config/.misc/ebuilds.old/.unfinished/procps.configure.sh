
LDFLAGS=-static ./configure \
--enable-option-checking \
--enable-silent-rules \
--disable-dependency-tracking \
--enable-largefile \
--disable-shared \
--enable-static \
--disable-fast-install \
--enable-libtool-lock \
--disable-nls \
--disable-rpath \
--disable-watch8bit \
--disable-libselinux \
--disable-pidof \
--disable-kill \
--disable-skill \
--disable-examples \
--disable-sigwinch \
--disable-wide-percent \
--disable-wide-memory \
--disable-modern-top \
--disable-numa \
--disable-w-from \
--disable-whining \
\
--with-pic \
--with-aix-soname=aix \
--with-gnu-ld \
--with-sysroot \
--with-gnu-ld \
--without-libiconv-prefix \
--without-libintl-prefix \
--without-ncurses \
--without-systemd \
--without-elogind

