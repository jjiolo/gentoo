
./configure \
--prefix=/usr \
--enable-option-checking \
--enable-silent-rules \
--disable-compat-symlinks \
--disable-atari-check \
--disable-dependency-tracking \
--enable-largefile \
--disable-rpath \
\
--without-iconv \
--with-gnu-ld \
--without-libiconv-prefix

