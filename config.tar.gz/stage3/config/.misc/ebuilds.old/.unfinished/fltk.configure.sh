
./configure\
 --prefix=/usr\
 --disable-cygwin\
 --enable-x11\
 --disable-cairoext\
 --disable-cairo\
 --disable-debug\
 --disable-cp936\
 --disable-gl\
 --enable-shared\
 --enable-threads\
 --enable-largefile\
 --disable-localjpeg\
 --disable-localzlib\
 --disable-localpng\
 --disable-xinerama\
 --enable-xft\
 --enable-xdbe\
 --enable-xfixes\
 --enable-xcursor\
 --enable-xrender\
 --without-abiversion\
 --without-optim\
 --without-archflags\
 --without-links\
 --with-x

