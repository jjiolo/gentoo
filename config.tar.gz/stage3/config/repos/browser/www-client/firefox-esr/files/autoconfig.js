pref("general.config.filename", "firefox.cfg");
pref("general.config.obscure_value", 0);
